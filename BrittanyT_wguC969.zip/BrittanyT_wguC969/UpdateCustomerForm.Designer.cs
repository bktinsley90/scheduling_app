﻿namespace BrittanyT_wguC969
{
    partial class UpdateCustomerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.SaveCustomerBtn = new System.Windows.Forms.Button();
            this.CancelCustomerBtn = new System.Windows.Forms.Button();
            this.IdLabel = new System.Windows.Forms.Label();
            this.NameLabel = new System.Windows.Forms.Label();
            this.AddressLabel = new System.Windows.Forms.Label();
            this.PhoneNumberLabel = new System.Windows.Forms.Label();
            this.CityLabel = new System.Windows.Forms.Label();
            this.StateLabel = new System.Windows.Forms.Label();
            this.PostalCodeLabel = new System.Windows.Forms.Label();
            this.CountryLabel = new System.Windows.Forms.Label();
            this.CustomerIdInput = new System.Windows.Forms.TextBox();
            this.CustomerNameInput = new System.Windows.Forms.TextBox();
            this.CustomerAddressInput = new System.Windows.Forms.TextBox();
            this.PhoneNumberInput = new System.Windows.Forms.TextBox();
            this.CityInput = new System.Windows.Forms.TextBox();
            this.StateInput = new System.Windows.Forms.TextBox();
            this.PostalCodeInput = new System.Windows.Forms.TextBox();
            this.CountryInput = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(171, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Update Customer";
            // 
            // SaveCustomerBtn
            // 
            this.SaveCustomerBtn.Location = new System.Drawing.Point(246, 392);
            this.SaveCustomerBtn.Name = "SaveCustomerBtn";
            this.SaveCustomerBtn.Size = new System.Drawing.Size(75, 23);
            this.SaveCustomerBtn.TabIndex = 1;
            this.SaveCustomerBtn.Text = "Save";
            this.SaveCustomerBtn.UseVisualStyleBackColor = true;
            this.SaveCustomerBtn.Click += new System.EventHandler(this.SaveCustomerBtn_Click);
            // 
            // CancelCustomerBtn
            // 
            this.CancelCustomerBtn.Location = new System.Drawing.Point(341, 392);
            this.CancelCustomerBtn.Name = "CancelCustomerBtn";
            this.CancelCustomerBtn.Size = new System.Drawing.Size(75, 23);
            this.CancelCustomerBtn.TabIndex = 2;
            this.CancelCustomerBtn.Text = "Cancel";
            this.CancelCustomerBtn.UseVisualStyleBackColor = true;
            this.CancelCustomerBtn.Click += new System.EventHandler(this.CancelBtn_Click);
            // 
            // IdLabel
            // 
            this.IdLabel.AutoSize = true;
            this.IdLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IdLabel.Location = new System.Drawing.Point(139, 69);
            this.IdLabel.Name = "IdLabel";
            this.IdLabel.Size = new System.Drawing.Size(21, 17);
            this.IdLabel.TabIndex = 3;
            this.IdLabel.Text = "ID";
            // 
            // NameLabel
            // 
            this.NameLabel.AutoSize = true;
            this.NameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NameLabel.Location = new System.Drawing.Point(115, 111);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(45, 17);
            this.NameLabel.TabIndex = 4;
            this.NameLabel.Text = "Name";
            // 
            // AddressLabel
            // 
            this.AddressLabel.AutoSize = true;
            this.AddressLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddressLabel.Location = new System.Drawing.Point(100, 148);
            this.AddressLabel.Name = "AddressLabel";
            this.AddressLabel.Size = new System.Drawing.Size(60, 17);
            this.AddressLabel.TabIndex = 5;
            this.AddressLabel.Text = "Address";
            // 
            // PhoneNumberLabel
            // 
            this.PhoneNumberLabel.AutoSize = true;
            this.PhoneNumberLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PhoneNumberLabel.Location = new System.Drawing.Point(57, 180);
            this.PhoneNumberLabel.Name = "PhoneNumberLabel";
            this.PhoneNumberLabel.Size = new System.Drawing.Size(103, 17);
            this.PhoneNumberLabel.TabIndex = 6;
            this.PhoneNumberLabel.Text = "Phone Number";
            // 
            // CityLabel
            // 
            this.CityLabel.AutoSize = true;
            this.CityLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CityLabel.Location = new System.Drawing.Point(129, 208);
            this.CityLabel.Name = "CityLabel";
            this.CityLabel.Size = new System.Drawing.Size(31, 17);
            this.CityLabel.TabIndex = 7;
            this.CityLabel.Text = "City";
            // 
            // StateLabel
            // 
            this.StateLabel.AutoSize = true;
            this.StateLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StateLabel.Location = new System.Drawing.Point(119, 249);
            this.StateLabel.Name = "StateLabel";
            this.StateLabel.Size = new System.Drawing.Size(41, 17);
            this.StateLabel.TabIndex = 8;
            this.StateLabel.Text = "State";
            // 
            // PostalCodeLabel
            // 
            this.PostalCodeLabel.AutoSize = true;
            this.PostalCodeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PostalCodeLabel.Location = new System.Drawing.Point(76, 289);
            this.PostalCodeLabel.Name = "PostalCodeLabel";
            this.PostalCodeLabel.Size = new System.Drawing.Size(84, 17);
            this.PostalCodeLabel.TabIndex = 9;
            this.PostalCodeLabel.Text = "Postal Code";
            // 
            // CountryLabel
            // 
            this.CountryLabel.AutoSize = true;
            this.CountryLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CountryLabel.Location = new System.Drawing.Point(103, 331);
            this.CountryLabel.Name = "CountryLabel";
            this.CountryLabel.Size = new System.Drawing.Size(57, 17);
            this.CountryLabel.TabIndex = 10;
            this.CountryLabel.Text = "Country";
            // 
            // CustomerIdInput
            // 
            this.CustomerIdInput.Enabled = false;
            this.CustomerIdInput.Location = new System.Drawing.Point(177, 68);
            this.CustomerIdInput.Name = "CustomerIdInput";
            this.CustomerIdInput.Size = new System.Drawing.Size(100, 20);
            this.CustomerIdInput.TabIndex = 11;
            this.CustomerIdInput.Text = "Auto-Generated";
            // 
            // CustomerNameInput
            // 
            this.CustomerNameInput.Location = new System.Drawing.Point(177, 110);
            this.CustomerNameInput.Name = "CustomerNameInput";
            this.CustomerNameInput.Size = new System.Drawing.Size(100, 20);
            this.CustomerNameInput.TabIndex = 12;
            // 
            // CustomerAddressInput
            // 
            this.CustomerAddressInput.Location = new System.Drawing.Point(177, 145);
            this.CustomerAddressInput.Name = "CustomerAddressInput";
            this.CustomerAddressInput.Size = new System.Drawing.Size(100, 20);
            this.CustomerAddressInput.TabIndex = 13;
            // 
            // PhoneNumberInput
            // 
            this.PhoneNumberInput.Location = new System.Drawing.Point(177, 180);
            this.PhoneNumberInput.Name = "PhoneNumberInput";
            this.PhoneNumberInput.Size = new System.Drawing.Size(100, 20);
            this.PhoneNumberInput.TabIndex = 14;
            // 
            // CityInput
            // 
            this.CityInput.Location = new System.Drawing.Point(177, 205);
            this.CityInput.Name = "CityInput";
            this.CityInput.Size = new System.Drawing.Size(100, 20);
            this.CityInput.TabIndex = 15;
            // 
            // StateInput
            // 
            this.StateInput.Location = new System.Drawing.Point(177, 246);
            this.StateInput.Name = "StateInput";
            this.StateInput.Size = new System.Drawing.Size(100, 20);
            this.StateInput.TabIndex = 16;
            // 
            // PostalCodeInput
            // 
            this.PostalCodeInput.Location = new System.Drawing.Point(177, 288);
            this.PostalCodeInput.Name = "PostalCodeInput";
            this.PostalCodeInput.Size = new System.Drawing.Size(100, 20);
            this.PostalCodeInput.TabIndex = 17;
            // 
            // CountryInput
            // 
            this.CountryInput.Location = new System.Drawing.Point(177, 328);
            this.CountryInput.Name = "CountryInput";
            this.CountryInput.Size = new System.Drawing.Size(100, 20);
            this.CountryInput.TabIndex = 18;
            // 
            // UpdateCustomerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(438, 450);
            this.Controls.Add(this.CountryInput);
            this.Controls.Add(this.PostalCodeInput);
            this.Controls.Add(this.StateInput);
            this.Controls.Add(this.CityInput);
            this.Controls.Add(this.PhoneNumberInput);
            this.Controls.Add(this.CustomerAddressInput);
            this.Controls.Add(this.CustomerNameInput);
            this.Controls.Add(this.CustomerIdInput);
            this.Controls.Add(this.CountryLabel);
            this.Controls.Add(this.PostalCodeLabel);
            this.Controls.Add(this.StateLabel);
            this.Controls.Add(this.CityLabel);
            this.Controls.Add(this.PhoneNumberLabel);
            this.Controls.Add(this.AddressLabel);
            this.Controls.Add(this.NameLabel);
            this.Controls.Add(this.IdLabel);
            this.Controls.Add(this.CancelCustomerBtn);
            this.Controls.Add(this.SaveCustomerBtn);
            this.Controls.Add(this.label1);
            this.Name = "UpdateCustomerForm";
            this.Text = "UpdateCustomerForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button SaveCustomerBtn;
        private System.Windows.Forms.Button CancelCustomerBtn;
        private System.Windows.Forms.Label IdLabel;
        private System.Windows.Forms.Label NameLabel;
        private System.Windows.Forms.Label AddressLabel;
        private System.Windows.Forms.Label PhoneNumberLabel;
        private System.Windows.Forms.Label CityLabel;
        private System.Windows.Forms.Label StateLabel;
        private System.Windows.Forms.Label PostalCodeLabel;
        private System.Windows.Forms.Label CountryLabel;
        private System.Windows.Forms.TextBox CustomerIdInput;
        private System.Windows.Forms.TextBox CustomerNameInput;
        private System.Windows.Forms.TextBox CustomerAddressInput;
        private System.Windows.Forms.TextBox PhoneNumberInput;
        private System.Windows.Forms.TextBox CityInput;
        private System.Windows.Forms.TextBox StateInput;
        private System.Windows.Forms.TextBox PostalCodeInput;
        private System.Windows.Forms.TextBox CountryInput;
    }
}